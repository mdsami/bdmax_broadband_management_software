-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 20, 2014 at 03:57 PM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bdmax`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblbilling`
--

CREATE TABLE IF NOT EXISTS `tblbilling` (
  `sl_no` int(15) NOT NULL AUTO_INCREMENT,
  `Receiver_Name` varchar(30) NOT NULL,
  `Member_Name` varchar(30) NOT NULL,
  `Member_ID` varchar(10) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `Month` varchar(20) NOT NULL,
  `Year` varchar(100) NOT NULL,
  `Bill` int(10) NOT NULL,
  `Due` int(10) NOT NULL,
  `Total` int(10) NOT NULL,
  `Status` varchar(10) NOT NULL,
  PRIMARY KEY (`sl_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tblbilling`
--

INSERT INTO `tblbilling` (`sl_no`, `Receiver_Name`, `Member_Name`, `Member_ID`, `Date`, `Month`, `Year`, `Bill`, `Due`, `Total`, `Status`) VALUES
(27, 'Rabi', '', 'max415', '06', 'Mar', '2014', 500, 0, 500, 'paid'),
(23, 'Rabi', '', 'max411', '06', 'Jan', '2014', 500, 0, 500, 'paid'),
(22, '', '', 'max410', '', 'Jan', '2014', 0, 0, 0, 'unpaid'),
(25, 'Milon', '', 'max413', '07', 'Feb', '2014', 1000, 0, 1000, 'paid'),
(24, '', '', 'max412', '', 'Jan', '2014', 0, 0, 0, 'unpaid'),
(26, '', '', 'max414', '', 'Feb', '2014', 0, 0, 0, 'unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `tblbillingstore`
--

CREATE TABLE IF NOT EXISTS `tblbillingstore` (
  `sl_no` int(11) NOT NULL AUTO_INCREMENT,
  `Receiver_Name` varchar(20) NOT NULL,
  `Member_Name` varchar(20) NOT NULL,
  `Member_ID` varchar(10) NOT NULL,
  `Date` int(11) NOT NULL,
  `Month` varchar(20) NOT NULL,
  `Year` int(11) NOT NULL,
  `Bill` int(11) NOT NULL,
  `Due` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  PRIMARY KEY (`sl_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tblbillingstore`
--

INSERT INTO `tblbillingstore` (`sl_no`, `Receiver_Name`, `Member_Name`, `Member_ID`, `Date`, `Month`, `Year`, `Bill`, `Due`, `Total`) VALUES
(9, 'Rabi', '', 'max412', 7, 'Jan', 2014, 10000, 0, 1000),
(8, 'Milon', 'Mahbuba', 'max410', 5, 'Jan', 2014, 1000, 0, 1000),
(10, '', 'Mahbuba', 'max410', 5, 'Jan', 2014, 1000, 0, 1000),
(11, '', '', 'max412', 7, 'Jan', 2014, 10000, 0, 1000),
(12, '', '', 'max410', 0, 'Jan', 2014, 0, 0, 0),
(13, '', '', 'max412', 0, 'Jan', 2014, 0, 0, 0),
(14, 'Rabi', '', 'max411', 6, 'Jan', 2014, 500, 0, 500),
(15, 'Milon', '', 'max413', 7, 'Feb', 2014, 1000, 0, 1000),
(16, 'Sami', '', 'max415', 5, 'Feb', 2014, 500, 0, 500),
(17, '', '', 'max415', 0, 'Mar', 2014, 0, 0, 0),
(18, 'Rabi', '', 'max415', 6, 'Mar', 2014, 500, 0, 500);

-- --------------------------------------------------------

--
-- Table structure for table `tblcredit`
--

CREATE TABLE IF NOT EXISTS `tblcredit` (
  `sl_no` int(11) NOT NULL AUTO_INCREMENT,
  `Date` varchar(30) NOT NULL,
  `Description` int(60) NOT NULL,
  `Cost` int(11) NOT NULL,
  PRIMARY KEY (`sl_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblcredit`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbldebit`
--

CREATE TABLE IF NOT EXISTS `tbldebit` (
  `sl_no` int(11) NOT NULL AUTO_INCREMENT,
  `Date` varchar(30) NOT NULL,
  `Description` varchar(60) NOT NULL,
  `Cost` int(11) NOT NULL,
  PRIMARY KEY (`sl_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbldebit`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblmember`
--

CREATE TABLE IF NOT EXISTS `tblmember` (
  `sl_no` int(11) NOT NULL AUTO_INCREMENT,
  `Member_Name` varchar(50) NOT NULL,
  `Join_Date` varchar(30) NOT NULL,
  `Member_ID` varchar(20) NOT NULL,
  `Speed` varchar(10) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Contact` varchar(15) NOT NULL,
  PRIMARY KEY (`sl_no`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `tblmember`
--

INSERT INTO `tblmember` (`sl_no`, `Member_Name`, `Join_Date`, `Member_ID`, `Speed`, `Address`, `Contact`) VALUES
(33, 'Jahid', '03.03.2014', 'max412', '256 Kbps', 'Badda', '01621547489'),
(31, 'Mahbuba', '01/01/2014', 'max410', '512 ZKbps', 'Gulshan,Dhaka', '016123456789'),
(32, 'Nahid', '05.01.2014', 'max411', '512 kbps', 'Badda', '01621345289');

-- --------------------------------------------------------

--
-- Table structure for table `tblusereg`
--

CREATE TABLE IF NOT EXISTS `tblusereg` (
  `member_id` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(200) NOT NULL,
  `Password` varchar(200) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tblusereg`
--

INSERT INTO `tblusereg` (`member_id`, `UserName`, `Password`) VALUES
(8, 'srabon', 'srabon'),
(6, 'salman', 'salman'),
(5, 'admin', 'admin');
